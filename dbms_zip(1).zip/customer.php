<?php
    if(isset($_POST))
    {
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $pc=$_POST['pc'];
        $sc=$_POST['sc'];
        $email=$_POST['email'];
        $nomname=$_POST['nomname'];
        $rel=$_POST['rel'];
        $nomcon=$_POST['nomcon'];
        $add = $_POST['add'];
        $db=new mysqli("localhost","root","","secure_stow");
        if($db->connect_error){
            echo "Connection failed due to " . $db->connect_error;
        }
        $stmt=$db->prepare("INSERT INTO customer (First_Name,Last_Name,Primary_Contact,	Secondary_Contact,Email_ID,Nominee_Name,Relationship,Nominee_Contact, Permanent_Address)VALUES(?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param("sssssssss",$fname,$lname,$pc,$sc,$email,$nomname,$rel,$nomcon,$add);
        if($stmt->execute()){
            echo '<script>alert("Added successfully,redirecting you to you login page"); setTimeout(function(){window.location.href = "login.php";}, 1500);</script>';
        }else{
            echo "Error adding the details";
        }
        $stmt->close();
        $db->close();
    }

?>