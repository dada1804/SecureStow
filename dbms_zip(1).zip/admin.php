<?php
session_start();
$db = new mysqli("localhost", "root", "", "secure_stow");
if($db->connect_error){
    echo "Error connecting the database" . $db->connect_error;
}
$stmt = $db->prepare("SELECT * FROM customer");
$stmt->execute();
$result = $stmt->get_result();
echo "<link rel='stylesheet' href='table.css'>";
echo "<br>";
echo '<div style="text-align: center; font-size:1.75em;"><b>Stower Personal Details</b></div>';
echo "<table>";
echo "<tr>";
echo "<th>Customer ID</th>";
echo "<th>First Name</th>";
echo "<th>Last Name</th>";
echo "<th>Primary Contact</th>";
echo "<th>Secondary Contact</th>";
echo "<th>Email ID</th>";
echo "<th>Nominee Name</th>";
echo "<th>Realationship</th>";
echo "<th>Nominee Contact</th>";
echo "</tr>";
while($row = $result->fetch_assoc()){
    echo "<tr>";
    echo "<td>" . $row['Cust_ID'] . "</td>";
    echo "<td>" . $row['First_Name'] . "</td>";
    echo "<td>" . $row['Last_Name'] . "</td>";
    echo "<td>" . $row['Primary_Contact'] . "</td>";
    echo "<td>" . $row['Secondary_Contact'] . "</td>";
    echo "<td>" . $row['Email_ID'] . "</td>";
    echo "<td>" . $row['Nominee_Name'] . "</td>";
    echo "<td>" . $row['Relationship'] . "</td>";
    echo "<td>" . $row['Nominee_Contact'] . "</td>";
    echo "</tr>";
}
echo "</table>";
$stmt1 = $db->prepare("SELECT * FROM household_items");
$stmt1->execute();
$result1 = $stmt1->get_result();
echo "<link rel='stylesheet' href='table.css'>";
echo "<br><br><br><br>";
echo '<div style="text-align: center; font-size:1.75em;"><b>Stower Household Details</b></div>';
echo "<table>";
echo "<tr>";
echo "<th>Customer ID</th>";
echo "<th>Number of large items</th>";
echo "<th>Number of small items</th>";
echo "<th>Duration in days</th>";
echo "<th>Email ID</th>";
echo "</tr>";
while($row = $result1->fetch_assoc()){
    echo "<tr>";
    echo "<td>" . $row['Cust_ID'] . "</td>";
    echo "<td>" . $row['No_of_large_items'] . "</td>";
    echo "<td>" . $row['No_of_small_items'] . "</td>";
    echo "<td>" . $row['Duration_in_days'] . "</td>";
    echo "<td>" . $row['Email_ID'] . "</td>";
    echo "</tr>";
}
echo "</table>";
echo "<br>";
$stmt2 = $db->prepare("SELECT * FROM price");
$stmt2->execute();
$result2 = $stmt2->get_result();
echo "<link rel='stylesheet' href='table.css'>";
echo '<div style="text-align: center; font-size:1.75em;"><b>Stower Automobile Details</b></div>';
echo "<table>";
echo "<tr>";
echo "<th>Customer ID</th>";
echo "<th>Price</th>";
echo "<th>Duration in days</th>";
echo "<th>Email ID</th>";
echo "</tr>";
while($row = $result2->fetch_assoc()){
    echo "<tr>";
    echo "<td>" . $row['Cust_ID'] . "</td>";
    echo "<td>" . $row['Price'] . "</td>";
    echo "<td>" . $row['Duration_in_days'] . "</td>";
    echo "<td>" . $row['Email_ID'] . "</td>";
    echo "</tr>";
}
echo "</table>";
echo '<p><a href=index.php class="update1"><button class="update2">Back to login</button></a></p>';
$stmt->close();
$db->close();
?>