<?php
session_start();
if (isset($_POST)&&isset($_SESSION)) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $pc = $_POST['pc'];
    $sc = $_POST['sc'];
    $nomname = $_POST['nomname'];
    $rel = $_POST['rel'];
    $nomcon = $_POST['nomcon'];
    $add = $_POST['add'];
    $user = $_SESSION['user'];
    $db=new mysqli("localhost","root","","secure_stow");
        if($db->connect_error){
            echo "Connection failed due to " . $db->connect_error;
        }
    $stmt = $db->prepare("UPDATE customer SET First_Name=? , Last_Name=?, Primary_Contact=?, Secondary_Contact=?, Nominee_Name=?, Relationship=?, Nominee_Contact=?, Permanent_Address=? WHERE Email_ID=?");
    $stmt->bind_param("sssssssss",$fname,$lname,$pc,$sc,$nomname,$rel,$nomcon,$add,$user );
    if($stmt->execute())
    {
        echo '<script>alert("Updated successfully,redirecting you to your profile"); setTimeout(function(){window.location.href = "info.php";}, 1500);</script>';
    }else{
        echo '<script>alert("Error updating the details, try again later...")</script>';
    }
}
?>