<?php
    session_start();
    if(isset($_POST)&&isset($_SESSION)){
        $large=$_POST['large'];
        $small=$_POST['small'];
        $user=$_SESSION['user'];
        $cid=$_POST['cid'];
        $dd=$_POST['dd'];
        $db = new mysqli("localhost", "root", "", "secure_stow");
        if($db->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }
        $stmt = $db->prepare("INSERT INTO household_items (Cust_ID,No_of_large_items,No_of_small_items,Email_ID,Duration_in_days)  VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iiisi", $cid, $large, $small, $user, $dd);
        $_SESSION['dd']=$dd;
        $_SESSION['li']=$large;
        $_SESSION['si']=$small;
        $_SESSION['cid']=$cid;
        if($stmt->execute()){
            // echo '<script>alert("Added successfully,redirecting you to your profile")</script>';
            // header("Location:user.php");
            echo '<script>alert("Added successfully,redirecting you to your profile"); setTimeout(function(){window.location.href = "price.php";}, 1000);</script>';
           
        }else{
            echo "Error";
        }
        $db->close();

    }
?>