<?php
   session_start();
  $db=new mysqli("localhost","root","","secure_stow"); 
    if(isset($_SESSION)){
        $user = $_SESSION['user'];
        $cid=$_SESSION['cid'];
        $dd=$_SESSION['dd'];
    $price = $_SESSION['price'];
        // $tf   = $_SESSION['tf'];
        // $li   = $_SESSION['li'];
        // $si   = $_SESSION['si'];
        // $cid  = $_SESSION['cid'];
      
    //$price=1099;
    $stmt=$db->prepare("UPDATE price SET Price=?,Duration_in_days=? WHERE Email_ID=?");
    $stmt->bind_param("iis",$price,$dd,$user);
   
     if($stmt->execute()){
        echo '<script>alert("Added successfully,redirecting you to your profile"); setTimeout(function(){window.location.href = "user.php";}, 1500);</script>';
        exit;
     }
    }

?>